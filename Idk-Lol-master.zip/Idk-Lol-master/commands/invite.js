exports.run = (client, message, args) => {

	if (message.author.id !== "335430609860296705")return;
	message.reply("Hey! Use this link to add me to your server!\nhttps://discordapp.com/api/oauth2/authorize?client_id=442378357250719764&permissions=0&scope=bot");
}




