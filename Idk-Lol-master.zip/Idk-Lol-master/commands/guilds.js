module.exports.run = async (client, message, args) => {
    if (message.author.id !== "335430609860296705") return;
    message.react("✅") 
    message.author.send(`= Guild List =\n\n${client.guilds.map(g => g.name).join("\n")}`, {code:'asciidoc'});
    }