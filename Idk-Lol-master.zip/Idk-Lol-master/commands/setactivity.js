const config = require("./config.json");

exports.run = (client, message, args) => {
if (!config.owners.includes(message.author.id))
    let game = message.content.split(' ').slice(1)
    let playing = game.join(' ')
    message.reply("New Game Set");
    client.user.setGame(playing)
    }