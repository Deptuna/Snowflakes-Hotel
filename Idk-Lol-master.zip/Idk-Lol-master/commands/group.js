const Discord = require("discord.js");

module.exports.run = async (bot, message, args) =>{

    message.channel.send("Official Snowflake Hotels group! https://web.roblox.com/My/Groups.aspx?gid=4129939")
}
