exports.run = (client, message, args) => {
    if (message.author.id !== "335430609860296705") return;
    let doit = message.content.split(" ").slice(1);
    let pikapi = doit.join(" ");
    message.reply('New Name Set!');
    client.user.setUsername(pikapi);
    }