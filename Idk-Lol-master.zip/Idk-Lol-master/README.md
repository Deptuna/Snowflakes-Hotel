# Snowflakes Hotel Bot
For a group for snowlflakes Hotel
